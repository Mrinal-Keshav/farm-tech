import IntegratedDashboard from './IntegratedDashboard';

const Dashboard = () => {
  return <IntegratedDashboard />;
};

export default Dashboard;