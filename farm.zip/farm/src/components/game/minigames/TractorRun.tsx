import React, { useCallback, useEffect, useState, useRef } from 'react';
import { X, Trophy, Heart, AlertTriangle } from 'lucide-react';
interface GameObject {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'player' | 'crop' | 'obstacle' | 'powerup';
  emoji: string;
  speed?: number;
}
interface TractorRunProps {
  onClose: () => void;
  onScoreUpdate?: (score: number) => void;
}
const TractorRun: React.FC<TractorRunProps> = ({
  onClose,
  onScoreUpdate
}) => {
  // Game canvas dimensions
  const gameWidth = 800;
  const gameHeight = 500;
  // Game state
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [combo, setCombo] = useState(0);
  const lastCropTimeRef = useRef<number>(0);
  const [player, setPlayer] = useState<GameObject>({
    x: 50,
    y: gameHeight / 2 - 25,
    width: 50,
    height: 50,
    type: 'player',
    emoji: '🚜'
  });
  const [gameObjects, setGameObjects] = useState<GameObject[]>([]);
  const [gameSpeed, setGameSpeed] = useState(5);
  const [lastSpawnTime, setLastSpawnTime] = useState(0);
  // Refs
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const keysPressed = useRef<Set<string>>(new Set());
  // Load high score from localStorage
  useEffect(() => {
    const savedHighScore = localStorage.getItem('tractorRunHighScore');
    if (savedHighScore) {
      setHighScore(parseInt(savedHighScore));
    }
  }, []);
  // Save high score to localStorage
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem('tractorRunHighScore', score.toString());
    }
  }, [score, highScore]);
  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current.add(e.code);
      // Start game with any key if not started
      if (!gameStarted && !gameOver) {
        setGameStarted(true);
      }
      // Restart game with Enter if game over
      if (gameOver && e.code === 'Enter') {
        restartGame();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current.delete(e.code);
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameStarted, gameOver]);
  // Game loop
  const gameLoop = useCallback(() => {
    if (!gameStarted || gameOver) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    // Clear canvas
    ctx.clearRect(0, 0, gameWidth, gameHeight);
    // Draw background (field)
    ctx.fillStyle = '#9bdb4d';
    ctx.fillRect(0, 0, gameWidth, gameHeight);
    // Draw rows in the field
    ctx.strokeStyle = '#85c73c';
    ctx.lineWidth = 2;
    for (let i = 0; i < gameHeight; i += 50) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(gameWidth, i);
      ctx.stroke();
    }
    // Update player position based on keys pressed (up/down/left/right)
    const updatedPlayer = { ...player };
    if (keysPressed.current.has('ArrowUp') || keysPressed.current.has('KeyW')) {
      updatedPlayer.y = Math.max(0, player.y - 10);
    }
    if (keysPressed.current.has('ArrowDown') || keysPressed.current.has('KeyS')) {
      updatedPlayer.y = Math.min(gameHeight - player.height, player.y + 10);
    }
    if (keysPressed.current.has('ArrowLeft') || keysPressed.current.has('KeyA')) {
      updatedPlayer.x = Math.max(0, player.x - 10);
    }
    if (keysPressed.current.has('ArrowRight') || keysPressed.current.has('KeyD')) {
      updatedPlayer.x = Math.min(gameWidth - player.width, player.x + 10);
    }
    setPlayer(updatedPlayer);
    // Draw player
    ctx.font = '40px Arial';
    ctx.textBaseline = 'top';
    ctx.fillText(player.emoji, player.x, player.y);
    // Spawn new objects
    const now = Date.now();
    if (now - lastSpawnTime > 900) {
      spawnRandomObject();
      setLastSpawnTime(now);
      // Increase game speed over time
      if (score > 0 && score % 10 === 0) {
        setGameSpeed(prev => Math.min(prev + 0.5, 15));
      }
    }
    // Update and draw game objects
    const updatedObjects: GameObject[] = [];
    for (const obj of gameObjects) {
      // Move object to the left
      const updatedObj = {
        ...obj,
        x: obj.x - (obj.speed || gameSpeed)
      };
      // Check if object is still in view
      if (updatedObj.x + updatedObj.width > 0) {
        // Draw object
        ctx.font = '40px Arial';
        ctx.textBaseline = 'top';
        ctx.fillText(obj.emoji, updatedObj.x, updatedObj.y);
        // Check collision with player
        if (checkCollision(player, updatedObj)) {
          if (updatedObj.type === 'crop') {
            // Collected a crop with combo multiplier if collected quickly
            const nowTs = Date.now();
            if (nowTs - (lastCropTimeRef.current || 0) < 1200) {
              setCombo(prev => Math.min(prev + 1, 10));
            } else {
              setCombo(1);
            }
            lastCropTimeRef.current = nowTs;
            const points = 1 * combo || 1;
            setScore(prev => prev + points);
            if (onScoreUpdate) onScoreUpdate(score + 1);
            // Don't add this object to updated objects (remove it)
            continue;
          } else if (updatedObj.type === 'obstacle') {
            // Hit an obstacle (tree, fire, stone) -> lose a life; end when 0 lives
            setCombo(0);
            setLives(prev => {
              const next = Math.max(0, prev - 1);
              if (next <= 0) {
                setGameOver(true);
              }
              return next;
            });
            // Don't add this object to updated objects (remove it)
            continue;
          } else if (updatedObj.type === 'powerup') {
            // Got a powerup (extra life)
            setLives(prev => Math.min(prev + 1, 5));
            setCombo(0);
            // Don't add this object to updated objects (remove it)
            continue;
          }
        }
        updatedObjects.push(updatedObj);
      }
    }
    setGameObjects(updatedObjects);
    // Draw score and lives
    ctx.fillStyle = 'black';
    ctx.font = '20px Arial';
    ctx.fillText(`Score: ${score}`, 20, 20);
    if (combo > 1) {
      ctx.fillStyle = 'darkred';
      ctx.font = 'bold 16px Arial';
      ctx.fillText(`Combo x${combo}`, 20, 42);
      ctx.fillStyle = 'black';
      ctx.font = '20px Arial';
    }
    // Draw lives
    for (let i = 0; i < lives; i++) {
      ctx.fillText('❤️', gameWidth - 40 - i * 30, 20);
    }
    // Continue game loop
    animationRef.current = requestAnimationFrame(gameLoop);
  }, [gameStarted, gameOver, player, gameObjects, score, lives, gameSpeed, lastSpawnTime, onScoreUpdate]);
  // Start/stop game loop
  useEffect(() => {
    if (gameStarted && !gameOver) {
      animationRef.current = requestAnimationFrame(gameLoop);
    }
    return () => {
      cancelAnimationFrame(animationRef.current);
    };
  }, [gameStarted, gameOver, gameLoop]);
  // Check collision between two game objects
  const checkCollision = (obj1: GameObject, obj2: GameObject) => {
    // Simple bounding box collision
    const adjustedSize = 30; // Adjust collision box to be smaller than the emoji
    return obj1.x < obj2.x + adjustedSize && obj1.x + adjustedSize > obj2.x && obj1.y < obj2.y + adjustedSize && obj1.y + adjustedSize > obj2.y;
  };
  // Spawn a random game object
  const spawnRandomObject = () => {
    // Crops/vegetables increase score; trees/fire/stone end the game
    const types = ['crop', 'crop', 'obstacle', 'crop', 'obstacle', 'crop', 'powerup'];
    const randomType = types[Math.floor(Math.random() * types.length)];
    let emoji = '🌾';
    if (randomType === 'crop') {
      const cropEmojis = ['🌾', '🌽', '🥔', '🫘', '🍚', '🥕', '🍅'];
      emoji = cropEmojis[Math.floor(Math.random() * cropEmojis.length)];
    } else if (randomType === 'obstacle') {
      const obstacleEmojis = ['🪨', '🌳', '🔥']; // stone, tree, fire
      emoji = obstacleEmojis[Math.floor(Math.random() * obstacleEmojis.length)];
    } else if (randomType === 'powerup') {
      emoji = '❤️';
    }
    const newObject: GameObject = {
      x: gameWidth,
      y: Math.random() * (gameHeight - 50),
      width: 40,
      height: 40,
      type: randomType,
      emoji: emoji,
      speed: gameSpeed + (Math.random() * 2 - 1) // Slight speed variation
    };
    setGameObjects(prev => [...prev, newObject]);
  };
  // Restart game
  const restartGame = () => {
    setGameStarted(false);
    setGameOver(false);
    setScore(0);
    setLives(3);
    setGameSpeed(5);
    setPlayer({
      x: 50,
      y: gameHeight / 2 - 25,
      width: 50,
      height: 50,
      type: 'player',
      emoji: '🚜'
    });
    setGameObjects([]);
  };
  return <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-70 z-50">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden max-w-4xl w-full">
        <div className="flex justify-between items-center bg-green-700 text-white p-4">
          <h2 className="text-xl font-bold">Tractor Run</h2>
          <button onClick={onClose} className="text-white hover:text-gray-200">
            <X className="h-6 w-6" />
          </button>
        </div>
        <div className="p-4 bg-green-50">
          {!gameStarted && !gameOver ? <div className="text-center py-8">
              <h3 className="text-2xl font-bold mb-4">Tractor Run</h3>
              <p className="mb-6 text-gray-700">
                Drive your tractor through the fields! Collect crops and avoid
                obstacles.
              </p>
              <div className="flex justify-center space-x-8 mb-8">
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-2">🌾 🌽 🥔</div>
                  <p>Collect crops for points</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-2">🪨 🌳 🔥</div>
                  <p>Avoid obstacles</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-2">❤️</div>
                  <p>Extra life</p>
                </div>
              </div>
              <div className="bg-gray-100 rounded-lg p-4 inline-block mb-6">
                <p className="font-medium">Controls:</p>
                <p>↑ or W: Move Up</p>
                <p>↓ or S: Move Down</p>
              </div>
              <button onClick={() => setGameStarted(true)} className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition-colors">
                Start Game
              </button>
              {highScore > 0 && <div className="mt-4 flex justify-center items-center">
                  <Trophy className="h-5 w-5 text-yellow-500 mr-2" />
                  <span>High Score: {highScore}</span>
                </div>}
            </div> : gameOver ? <div className="text-center py-8">
              <h3 className="text-2xl font-bold mb-2">Game Over</h3>
              <p className="mb-4 text-gray-700">You collected {score} crops!</p>
              {score >= highScore && <div className="mb-6 text-yellow-600 flex justify-center items-center">
                  <Trophy className="h-6 w-6 mr-2" />
                  <span className="font-bold">New High Score!</span>
                </div>}
              <button onClick={restartGame} className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition-colors">
                Play Again
              </button>
            </div> : <div className="flex justify-center">
              <canvas ref={canvasRef} width={gameWidth} height={gameHeight} className="border border-gray-300 rounded-lg" />
            </div>}
          {gameStarted && !gameOver && <div className="flex justify-between items-center mt-4">
              <div className="flex items-center">
                <span className="mr-4">Score: {score}</span>
                <div className="flex items-center">
                  <Heart className="h-5 w-5 text-red-500 mr-1" />
                  <span>{lives}</span>
                </div>
              </div>
              <div className="text-sm text-gray-500">
                <AlertTriangle className="h-4 w-4 inline mr-1" />
                Press ESC to exit
              </div>
            </div>}
        </div>
      </div>
    </div>;
};
export default TractorRun;
