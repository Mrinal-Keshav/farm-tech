import Landing from "@/components/Landing";

const Index = () => {
  return <Landing />;
};

export default Index;
