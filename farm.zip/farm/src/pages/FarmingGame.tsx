import GameDashboard from "@/components/game/GameDashboard";

const FarmingGame = () => {
  return <GameDashboard />;
};

export default FarmingGame;